#include <iostream>
#include <fstream>


#ifdef DEBUG_MODE

extern unsigned int MASK ;
#define DBG(A,B) { if ((A) & MASK) {B;}}

#else 

#define DBG(A,B)

#endif

/** Tracing dell'indirizzo della testa della lista degli utenti */
#define D1(a) DBG(1, a)
/** Tracing dei campi di una nuova risorsa inserita */   
#define D2(a) DBG(2, a)


/* Inzio header modulo Struttura Dati */

/**Lunghezza massisa della stringhe */
const int max_c = 70;

/** Nome del file .txt in cui vengono salvate le risorse. */
extern char NOME_FILE_OBJ[];

/** Nome del file .txt in cui vengono salvati gli utenti. */
extern char NOME_FILE_PEO[];

/** Variabile globale che tiene aggiornato il numero delle risorse in mediateca 
  * e rappresenta anche l'identificativo univoco che viene attribuito ad ogni 
  * risorsa alla sua creazione.
  */
extern int last_id_obj ;

/** Variabile globale che tiene aggiornato il numero degli utenti in mediateca 
  * e rappresenta anche l'identificativo univoco che viene attribuito ad ogni 
  * utente alla sua creazione.
  */
extern int last_id_people;

/** Il tipo di struct object rappresenta ogni risorsa della mediateca. 
  * Esso è costituito da vari campi quali: titolo, nome autore, cognome autore, 
  * data di rilascio della risorsa, casa editrice, id, id dell'attuale utente 
  * che detiene la risorsa, stato, categoria e tipologia.
  */
struct elem_obj { /** Nome dell'autore-regista-cantante. */
                char author_name [max_c] ;

                /** Cognome dell'autore-regista-cantante. */
                char author_surname [max_c] ;

                /** Titolo dell'oggetto. */
                char title [max_c] ;
                
                /** Data di uscita dell'oggeto.
                  * 
                  * Ha questo formato di dato perchè in questo modo grazie alla 
                  * libreria ctime posso confrontare tra loro varie date e fare 
                  * altre operazioni utili per possibili implementazioni future.
                  * Ricordarsi che il campo mese di questo formato di dato va da
                  * 0 a 11 anzichè da 1 a 12 come sarebbe logico pensare, per questo
                  * nella stampa bisogna sempre formattare opportunamente il campo 
                  * relativo.
                  */
                struct tm rel_date ;

                /** Casa produttrice-editrice-discografica. */
                char manifacturer [max_c] ;

                /** Codice identificativo del documento. 
                  * 
                  * E' progressivo e univoco, non dà informazioni 
                  * di alcun tipo sull'oggetto.
                  */
                int id;
          
                /** Tipo del documento: libro=0, ebook=1, dvd=2, cd=3, rivista=4. */
                int type;

                /** Categoria a cui appartiene l'oggetto.
                  * 
                  * narrativa_1=0, narrativa_2=1, narrativa_3=2, albo_illustrato=3,
                  * storia=4, geografia=5, scienze=6, arte=7, intercultura=8, 
                  * libri_insegnanti=9, francese=10, inglese=11, 
                  * tecnologia_informatica=12
                  */
                int category;

                /** Stato del documento: libero=0, in prestito=1. */
                int status;

                /** Data di restituzione prevista.
                  *
                  * Se è uguale a 0, vuole dire che il documento è attualmente disponibile.
                  * Il formato del dato è come quello di rel_date . */
                struct tm *return_date;
 
                /** Id dell'utente che ha attualmente in prestito l'oggetto. 
                  *
                  * Se è settato a 0 il documento è attualmente disponibile.
                  */
                int id_actual_user;

                /** Puntatore all'elemento successivo.
                  */
                elem_obj *pun;
               

              };

typedef elem_obj *lista_obj;

/** Il tipo di dato struct elem_peolpe serve per rappresentare le generalità di base di ogni utente.
  * Come generalità di base sono state considerate : nome, cognome, ID, numero di telefono e anno di 
  * nascita. 
  */
struct elem_people { /** Nome dell'utente.
                       */
                     char user_name [max_c] ;

                     /** Cognome dell'utente.
                       */
                     char user_surname [max_c] ;


                     /** Codice identificativo di ogni utente.
                       *
                       * E' progressivo e univoco per ogni utente.
                       */
                     int id;

                     /** Numero di telefono associato all'utente.
                       */
                     long int n_telefono ;

                     /** Anno di nascita.
                       *
                       * Metodo elementare per evitare problemi di scambio di 
                       * identità nel caso ci siano ominimie tra utenti.
                       */
                     int birth_year ;
                     
                     /** Puntatore all'elemento successivo nella lista.
                       */
                     elem_people *pun_p ;
                     
                     
                   } ;

typedef elem_people *lista_people ; 

extern lista_obj testa_obj ;
extern lista_people testa_people ;

/* Fine header del modulo Struttura Dati */
