/**
 * @mainpage Media-library
 *
 * Programma per la gestione dei contenuti di una mediateca scolastica. 
 *
 *
 * Il programma consente di : immettere un utente o risorsa nel sistema, 
 * eliminarlo, cercarlo, e nel caso dell'utente modificarne il numero di 
 * telefono. Inoltre permette di inserire un prestito, ritornarlo e prorogarlo.
 * 
 * Prima di ogni sessione è necessario caricare i dati tramite il comando 
 * apposito nella menubar della pagina principale inoltre alla fine della 
 * sessione se si vogliono mantenere i cambiamenti fatti è necessario salvarli 
 * tramite il pulsante apposito sempre nella menu bar della pagina principale.
 *
 * Il programma è stato realizzato in modo tale da minimizzare al massimo la 
 * diffusione dei dati personali degli utenti; è per questo motivo che viene 
 * sempre richiesto l'ID e non il nome e cognome dell'utente per compiere le 
 * varie azioni. Per questo motivo si presuppone che ogni utente possegga una
 * ipotetica tessera della mediateca in cui siano presenti i prorpi dati e che 
 * essa venga presentata come identificativo al momento per prestito/reso di una 
 * risorsa.
 *
 * La sintassi per lanciare il programma da riga di comando e' la seguente:
 * make MediaLib
 * 
 * Per altri dettagli sul funzionnamento del programma vedere la funzione ::main
 *
 * @author Giorgia Gibellini
 */
#include <iostream>
#include <ctime>
#include <gtk/gtk.h>
#include <string.h>
#include <sstream>
#include <cstdlib>
#include <fstream>

#include <cassert>

using namespace std;

#include "struttura_dati.h"
#include "inserisci_elimina.h"
#include "operazioni_ricerca.h"
#include "caricamento_salvataggio.h"

#ifdef DEBUG_MODE
unsigned int MASK = 1;
#endif

char NOME_FILE_OBJ[] = "stato_risorse.txt" ;
char NOME_FILE_PEO[] = "stato_utenti.txt" ;

lista_obj testa_obj = new elem_obj ;
lista_people testa_people = new elem_people ;

int last_id_obj = 1;
int last_id_people = 1;

GtkBuilder *builder;

/** Chiude il programma con la finstra principale 
  */
extern "C" gboolean handler_delete_event(GtkWidget *widget, GdkEvent  *event, gpointer   user_data)  
{  
    gtk_main_quit() ;
    return TRUE ;
}

/** Nasconde la finestra voluta. 
  */
extern "C" void hide_main_window(GtkButton *button, gpointer user_data)
{
	gtk_widget_hide(gtk_widget_get_toplevel(GTK_WIDGET(button)));
}

/** Apre la applicationwindow a seconda della scelta del radiobuttion fatta. 
  */
extern "C" void handler_activate_choice (GtkMenuItem *menuitem, gpointer applicationwindow)
{
  	gtk_widget_show_all(GTK_WIDGET(applicationwindow));
}

/** Apre la applicationwindow scelta. 
  */
extern "C" void handler_activate_applicationwindow (GtkMenuItem *menuitem, gpointer applicationwindow)
{ 
    gtk_widget_show_all(GTK_WIDGET(applicationwindow));  
}

/** Apre la dialog scelta. 
  */
extern "C" void handler_activate_dialog (GtkMenuItem *menuitem, gpointer dialog)
{
  	gtk_widget_show_all(GTK_WIDGET(dialog));
}


extern "C" void inserisci_user() 
{
    GtkWidget *applicationwindow1 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow1")) ;
    gtk_widget_show_all(applicationwindow1) ; 
}

/** Chiama la funzione per inserire un nuovo utente ::ins_people 
  */
extern "C" void inserisci_user_insert()    
{
    D1(cout<<"Indirizzo di testa_people dentro a inserisci_user_insert"<<&testa_people<<endl);

    ins_people(testa_people) ;
    
    //Svuoto le entry per la prossima immissione di dati
    GtkEntry * entry1 = GTK_ENTRY(gtk_builder_get_object(builder, "entry1"));
    gtk_entry_set_text(entry1, "");
    GtkEntry * entry2 = GTK_ENTRY(gtk_builder_get_object(builder, "entry2"));
    gtk_entry_set_text(entry2, ""); 
    GtkEntry * entry3 = GTK_ENTRY(gtk_builder_get_object(builder, "entry3"));
    gtk_entry_set_text(entry3, ""); 
    GtkEntry * entry4 = GTK_ENTRY(gtk_builder_get_object(builder, "entry4"));
    gtk_entry_set_text(entry4, "");

    //Faccio chiudere la applicationwindow
    GtkWidget *applicationwindow1 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow1")) ;
    gtk_widget_hide(applicationwindow1) ;
}

extern "C" void inserisci_tel()
{   
    GtkWidget *applicationwindow3 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow3")) ;
    gtk_widget_show_all(applicationwindow3) ;
} 

/** Chiama la funzione per modificare un utente ::modifica_utente 
  */
extern "C" void inserisci_tel_insert() 
{   D1(cout<<"Indirizzo di testa_people dentro a inserisci_tel_insert"<<&testa_people<<endl);

    modifica_utente (testa_people);

    //Svuoto le entry per la prossima immissione di dati
    GtkEntry * entry10 = GTK_ENTRY(gtk_builder_get_object(builder, "entry10"));
    gtk_entry_set_text(entry10, "");
    GtkEntry * entry11 = GTK_ENTRY(gtk_builder_get_object(builder, "entry11"));
    gtk_entry_set_text(entry11, ""); 

    //Faccio chiudere la applicationwindow
    GtkWidget *applicationwindow3 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow3")) ;
    gtk_widget_hide(applicationwindow3) ;    
}

extern "C" void cerca_user() 
{
    GtkWidget *applicationwindow4 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow4")) ;
    gtk_widget_show_all(applicationwindow4) ;
}

/** Chiama la funzione per cercare un utente ::cerca_people_nominativo 
  */
extern "C" void cerca_user_insert() 
{  
    cerca_people_nominativo(testa_people);
   
    //Le seguenti righe di codice "puliscono" le entry
    GtkEntry * entry12 = GTK_ENTRY(gtk_builder_get_object(builder, "entry12"));
    gtk_entry_set_text(entry12, "");
    GtkEntry * entry13 = GTK_ENTRY(gtk_builder_get_object(builder, "entry13"));
    gtk_entry_set_text(entry13, ""); 
   
}
/** Pulisce la TextView e chiude la applicationwindow
  */
extern "C" void cerca_user_close()
{  
    GtkTextView * textview1 = GTK_TEXT_VIEW(gtk_builder_get_object(builder, "textview1"));
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(textview1);
    gtk_text_buffer_set_text(buffer,"",-1);

    GtkWidget *applicationwindow4 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow4")) ;
    gtk_widget_hide(applicationwindow4) ;
}

extern "C" void elimina_user() 
{   
    GtkWidget *applicationwindow5 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow5")) ;
    gtk_widget_show_all(applicationwindow5) ;
}

/** Chiama la funzione per eliminare un utente ::elimina_people 
  */
extern "C" void elimina_user_insert() 
{     
    elimina_people(testa_people) ;

    GtkEntry * entry14 = GTK_ENTRY(gtk_builder_get_object(builder, "entry14"));
    gtk_entry_set_text(entry14, "");

    //Faccio chiudere la applicationwindow 
    GtkWidget *applicationwindow5 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow5")) ;
    gtk_widget_hide(applicationwindow5) ; 
   
}

/** Menu che permette tramite radiobutton di scegliere quale azione compiere.
  * Le azioni possibili sono : inserire un nuovo utente nel sistema, 
  * modificare il numero di telefono di un utente già registrato, cercare e 
  * stampare le informazioni relative ad un utente tramite nome e cognome ed
  * eliminare un utente registrato dal sistema.
  * Dopo aver effettuato la scelta selezionando il radiobutton, per renderla 
  * effettiva è necessario cliccare sul pulsante "Conferma" della finestra. 
  */
extern "C" void menu_user(GtkButton *button, gpointer user_data)
{
   if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton1"))))
    inserisci_user() ;
   else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton2"))))
    { assert(last_id_people>1);
      inserisci_tel() ; 
    }
   else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton3")))) 
    cerca_user();
   else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton4"))))
    { assert(last_id_people>1);
      elimina_user() ;
    }

  /* Questo pezzo di codice serve a fare si che, non appena la scelta con i 
      radio button viene fatta e confermata, si chiuda la finestra di menu e si
      apra la finestra scelta. */
 
  GtkWidget *dialog1 = GTK_WIDGET(gtk_builder_get_object(builder, "dialog1")) ;
  gtk_widget_hide(dialog1) ;
    	
}


extern "C" void inserisci_risorsa() 
{
    GtkWidget *applicationwindow6 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow6")) ;
    gtk_widget_show_all(applicationwindow6) ;
}

/** Chiama la funzione per inserire una risorsa ::ins_obj 
  */
extern "C" void inserisci_risorsa_insert()    
{
    ins_obj(testa_obj) ;
 
    GtkEntry * entry17 = GTK_ENTRY(gtk_builder_get_object(builder, "entry17"));
    gtk_entry_set_text(entry17, "");
    GtkEntry * entry18 = GTK_ENTRY(gtk_builder_get_object(builder, "entry18"));
    gtk_entry_set_text(entry18, ""); 
    GtkEntry * entry19 = GTK_ENTRY(gtk_builder_get_object(builder, "entry19"));
    gtk_entry_set_text(entry19, ""); 
    GtkEntry * entry20 = GTK_ENTRY(gtk_builder_get_object(builder, "entry20"));
    gtk_entry_set_text(entry20, "");
    GtkEntry * entry21 = GTK_ENTRY(gtk_builder_get_object(builder, "entry21"));
    gtk_entry_set_text(entry21, "");
    GtkEntry * entry22 = GTK_ENTRY(gtk_builder_get_object(builder, "entry22"));
    gtk_entry_set_text(entry22, ""); 
    GtkEntry * entry23 = GTK_ENTRY(gtk_builder_get_object(builder, "entry23"));
    gtk_entry_set_text(entry23, ""); 
    GtkEntry * entry24 = GTK_ENTRY(gtk_builder_get_object(builder, "entry24"));
    gtk_entry_set_text(entry24, "");
    GtkEntry * entry25 = GTK_ENTRY(gtk_builder_get_object(builder, "entry25"));
    gtk_entry_set_text(entry25, ""); 
    GtkEntry * entry26 = GTK_ENTRY(gtk_builder_get_object(builder, "entry26"));
    gtk_entry_set_text(entry26, ""); 
    GtkEntry * entry27 = GTK_ENTRY(gtk_builder_get_object(builder, "entry27"));
    gtk_entry_set_text(entry27, "");
    GtkEntry * entry28 = GTK_ENTRY(gtk_builder_get_object(builder, "entry28"));
    gtk_entry_set_text(entry28, "");

    /* Faccio chiudere la applicationwindow */
    GtkWidget *applicationwindow6 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow6")) ;
    gtk_widget_hide(applicationwindow6) ; 
}



extern "C" void elimina_risorsa() 
{   
    GtkWidget *applicationwindow2 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow2")) ;
    gtk_widget_show_all(applicationwindow2) ;
}

/** Chiama la funzione per eliminare una risorsa ::elimina_obj 
  */
extern "C" void elimina_risorsa_insert() 
{    
    elimina_obj(testa_obj) ;

    GtkEntry * entry5 = GTK_ENTRY(gtk_builder_get_object(builder, "entry5"));
    gtk_entry_set_text(entry5, "");

    /* Faccio chiudere la applicationwindow */
    GtkWidget *applicationwindow2 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow2")) ;
    gtk_widget_hide(applicationwindow2) ; 
}


extern "C" void cerca_risorsa() 
{   
    GtkWidget *applicationwindow7 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow7")) ;
    gtk_widget_show_all(applicationwindow7) ;
}

/** Chiama la funzione per cercare una risorsa ::stampa_obj_per_titolo 
  */
extern "C" void cerca_risorsa_insert() 
{   
    stampa_obj_per_titolo (testa_obj);

    /* Le seguenti righe di codice "puliscono" la entry */
    GtkEntry * entry6 = GTK_ENTRY(gtk_builder_get_object(builder, "entry6"));
    gtk_entry_set_text(entry6, "");
}

/** Pulisce la TextView e chiude la applicationwindow 
  */
extern "C" void cerca_risorsa_close()
{  /* Le seguenti righe di codice "puliscono" la textviw */
    GtkTextView * textview2 = GTK_TEXT_VIEW(gtk_builder_get_object(builder, "textview2"));
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(textview2);
    gtk_text_buffer_set_text(buffer,"",-1);

    /* Faccio chiudere la applicationwindow */
    GtkWidget *applicationwindow7 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow7")) ;
    gtk_widget_hide(applicationwindow7) ;
}

/** Aggancio a ogni bottone premuto del menu Area_risorse la chiamata della 
  * propria finestra di azione e relative funzioni annesse.
  * Menu che permette tramite radiobutton di scegliere quale azione compiere.
  * Le azioni a disposizione sono : inserire una risorsa nella mediateca, 
  * eliminare una risorsa dalla mediateca oppure cercare e visualizzare i dati 
  * relativi a una risorsa.
  * Dopo aver effettuato la scelta selezionando il radiobutton, per renderla 
  * effettiva è necessario cliccare sul pulsante "Conferma" della finestra.
  */
extern "C" void menu_risorse(GtkButton *button, gpointer user_data)
{ 
  if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton5"))))
       inserisci_risorsa() ; 
  else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton6"))))
     { assert(last_id_obj>1);
       elimina_risorsa(); 
     }
  else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton7")))) 
       cerca_risorsa();
  
   /* Questo pezzo di codice serve a fare si che, non appena la scelta con i 
      radio button viene fatta e confermata, si chiuda la finestra di menu e si
      apra la finestra scelta. 
    */
  GtkWidget *dialog2 = GTK_WIDGET(gtk_builder_get_object(builder, "dialog2")) ;
  gtk_widget_hide(dialog2) ;  
}

extern "C" void prestito_risorsa()
{   GtkWidget *applicationwindow8 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow8")) ;
    gtk_widget_show_all(applicationwindow8) ;
}

/** Chiama la funzione per eseguire un prestito ::immetti_prestito
  */
extern "C" void prestito_risorsa_insert()
{
  immetti_prestito(testa_obj, testa_people);

  GtkEntry * entry7 = GTK_ENTRY(gtk_builder_get_object(builder, "entry7"));
  gtk_entry_set_text(entry7, "");
  GtkEntry * entry8 = GTK_ENTRY(gtk_builder_get_object(builder, "entry8"));
  gtk_entry_set_text(entry8, "");

  //Faccio chiudere la applicationwindow
  GtkWidget *applicationwindow8 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow8")) ;
  gtk_widget_hide(applicationwindow8) ; 
}

extern "C" void restituzione_risorsa()
{   GtkWidget *applicationwindow9 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow9")) ;
    gtk_widget_show_all(applicationwindow9) ;
}

/** Chiama la funzione per rendere un prestito ::ritorna_prestito
  */
extern "C" void restituzione_risorsa_insert()
{
  ritorna_prestito(testa_obj);

  GtkEntry * entry15 = GTK_ENTRY(gtk_builder_get_object(builder, "entry15"));
  gtk_entry_set_text(entry15, "");

  //Faccio chiudere la applicationwindow
  GtkWidget *applicationwindow9 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow9")) ;
  gtk_widget_hide(applicationwindow9) ; 
}

extern "C" void proroga_risorsa()
{   GtkWidget *applicationwindow10 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow10")) ;
    gtk_widget_show_all(applicationwindow10) ;
}

/** Chiama la funzione per prorogare un prestito ::proroga_prestito
  */
extern "C" void proroga_risorsa_insert()
{ 
  //Le seguenti righe di codice "puliscono" la textviw 
  GtkTextView * textview3 = GTK_TEXT_VIEW(gtk_builder_get_object(builder, "textview3"));
  GtkTextBuffer *buffer = gtk_text_view_get_buffer(textview3);
  gtk_text_buffer_set_text(buffer,"",-1);

  proroga_prestito(testa_obj);

  //Le seguenti righe di codice "puliscono" la entry 
  GtkEntry * entry16 = GTK_ENTRY(gtk_builder_get_object(builder, "entry16"));
  gtk_entry_set_text(entry16, "");

}

/** Pulisce la TextView e chiude la applicationwindow
  */
extern "C" void proroga_prestito_close()
{  //Le seguenti righe di codice "puliscono" la textviw
    GtkTextView * textview3 = GTK_TEXT_VIEW(gtk_builder_get_object(builder, "textview3"));
    GtkTextBuffer *buffer = gtk_text_view_get_buffer(textview3);
    gtk_text_buffer_set_text(buffer,"",-1);

    //Faccio chiudere la applicationwindow 
    GtkWidget *applicationwindow10 = GTK_WIDGET(gtk_builder_get_object(builder, "applicationwindow10")) ;
    gtk_widget_hide(applicationwindow10) ;
}

/** Tramite i radiobutton e il click sul pulsante "Conferma" la funzione chiama
  * l'azione desiderata tra le seguenti : effettua un prestito, rendi un 
  * prestito oppure proroga un prestito.
  */
extern "C" void menu_prestiti(GtkButton *button, gpointer user_data)
{ /** Menu che permette tramite radiobutton di scegliere quale azione compiere.
    * Dopo aver effettuato la scelta selezionando il radiobutton, per renderla 
    * effettiva è necessario cliccare sul pulsante "Conferma" della finestra. 
    */
  if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton8"))))
       prestito_risorsa();
  else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton9"))))
       restituzione_risorsa();
  else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton10")))) 
       proroga_risorsa(); 

  /** Questo pezzo di codice serve a fare si che, non appena la scelta con i 
    * radio button viene fatta e confermata, si chiuda la finestra di menu e si
    * apra la finestra scelta. 
    */
  GtkWidget *dialog3 = GTK_WIDGET(gtk_builder_get_object(builder, "dialog3")) ;
  gtk_widget_hide(dialog3) ;   
}

/** Funzione che chiama le seguenti : ::carica_people e ::carica_obj
  */
void carica_tutto()
{   carica_people(testa_people);
    carica_obj(testa_obj);
   
    //Faccio chiudere la applicationwindow
    GtkWidget *dialog4 = GTK_WIDGET(gtk_builder_get_object(builder, "dialog4")) ;
    gtk_widget_hide(dialog4) ; 
}

/** Funzione che chiama le seguenti : ::salva_people e ::salva_obj
  */
void salva_tutto()
{  ofstream fp(NOME_FILE_PEO);
   assert (fp);
   salva_people(testa_people,fp);

   ofstream f(NOME_FILE_OBJ);
   assert(f);
   salva_obj(testa_obj, f); 

   //Faccio chiudere la applicationwindow
   GtkWidget *dialog4 = GTK_WIDGET(gtk_builder_get_object(builder, "dialog4")) ;
   gtk_widget_hide(dialog4) ;
}

/** Menu che permette di scegliere tramite radiobutton e click sul pulsante "Ok"
  * tra le due azioni : carica su file e salva su file. 
  * Ad ogni sessione è necessario, per ottenere i dati passati, fare il 
  * caricamento da file; allo stesso modo alla fine di ogni sessione per rendere
  * effettivi i cambiamenti attuati nel corso della stessa è necessario 
  * salvare su file.
  */ 
extern "C" void menu_carica_salva (GtkButton *button, gpointer user_data)
{
  if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton29"))))
	 carica_tutto();
  else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton30"))))
	 salva_tutto(); 
  
  GtkWidget *dialog3 = GTK_WIDGET(gtk_builder_get_object(builder, "dialog3")) ;
  gtk_widget_hide(dialog3) ; 
}

/** La funzione main permette di caricare l'interfaccia grafica e dare inizio
  * al ciclo di gestione degli eventi. L'interfaccia grafica permette di 
  * accedere alle varie funzionalità ovvero: 
  * - inserimento di una risorsa, implementato mediante la funzione ::ins_fondo_obj
  * - inserimento di un utente, implementato mediante la funzione ::ins_fondo_people
  * - immissione di un prestito, implementata mediante la funzione ::immetti_prestito
  * - restituzione di un prestito, implementata mediante la funzione ::ritorna_prestito
  * - proroga di un prestito, implementata mediante la funzione ::proroga_prestito
  * - modifica dati utente, implementata mediante la funzione ::modifica_utente
  * - elimina risorsa dalla mediateca, implementata mediante la funzione ::elimina_obj 
  * - elimina utente dalla mediateca, implementata mediante la funzione ::elimina_people 
  * - caricamento da file, implementata mediante le funzioni ::carica_people e ::carica_obj
  * - salvataggio su file, implementata mediante le funzioni ::salva_people e ::salva_obj
  * - cerca e stampa risorsa, implementata mediante la funzione ::stampa_obj_per_titolo
  * - cerca e stampa utente, implementata mediante la funzione ::cerca_people_nominativo
  */
int main(int argc, char *argv[])
{   D1(cout<<"Indirizzo di testa_people dentro al main"<<&testa_people<<endl);

   /* Parte di codice necessario per l'interfaccia */
 
    gtk_init(&argc, &argv);

    /* crea un nuovo oggetto GtkBuilder */
    builder = gtk_builder_new();
    
    /* Carica l'interfaccia dal file GI.glade */
    gtk_builder_add_from_file(builder,"GI.glade", NULL);

    /* Connette i segnali */
    gtk_builder_connect_signals(builder, NULL);

    /** partenza del ciclo di gestione degli eventi */
    gtk_main();


/** Fine della parte dedicata all'interfaccia */
   
return 0;
}
/* Fine del modulo Main */
