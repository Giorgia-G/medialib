/* Inizio header del modulo Operazioni/Ricerca */

// Il modulo Operazioni/Ricerca non ha una struttura dati propria

/* Inizio interfaccia del modulo Operazioni/Ricerca */

// Funzioni

/** Questa funzione prende in ingresso la testa della lista degli utenti e ha 
  * tipo di ritorno void. La funzione preleva dalle Entry nome e cognome dell'
  * utente da cercare e ne stampa i dati. Per fare ciò la funzione si serve 
  * della ::cerca_people_cognome_nome. Se il puntatore ritornato da quest'ultima 
  * funzione è nullo l'elemento non è stato trovato, altrimenti i dati dell'
  * utente vengono restituiti tramite la TextView sottostante alle Entry di 
  * ricerca. Nel caso in cui l'elemento non sia stato trovato ciò viene 
  * segnalato tramite la finestra di errore apposita.
  */
void cerca_people_nominativo(lista_people &testa_people);

/** La funzione serve per modificare il numero di telefono di un utente 
  * richiesto. 
  * Preleva dalle Entry l'ID dell'utente da modificare e il nuovo numero di 
  * telefono. Il numero di telefono viene convertito da string a long int 
  * tramite la funzione di libreria atol, l'ID viene convertito da string a int 
  * tramite la funzione atoi. Per cercare nella lista degli utenti quello 
  * deisderato si usa la funzione ::cerca_people_id. Se l'utente è stato trovato
  * la funzione ritorna il suo indirizzo, altrimenti ritorna un puntatore NULL.
  * Nel primo caso l'utente viene modificato come richiesto, nel secondo caso
  * viene mostrata una finestra di errore.
  */
void modifica_utente (lista_people &testa_people) ;

/** Questa funzione ha lo scopo di cercare e stampare una risorsa.
  * Se last_id_obj, che è il contatore degli oggetti della lista e ne indicizza 
  * anche l'ID, è minore di uno, non ci sono risorse, quindi viene mostrata una 
  * finestra di errore. In caso contrario si legge dalla Entry la stringa che 
  * rappresenta il titolo della risorsa cercata. Quindi la si passa alla 
  * funzione ::cerca_elem_titolo che restituisce NULL se non trova l'elemento o,
  * se lo trova, il suo indirizzo. Se l'elemento viene trovato se ne stampano
  * i dati tramite la TextView sottostante alla Entry di ricerca, altrimenti 
  * viene mostrata una finestra di errore.
  */
void stampa_obj_per_titolo (lista_obj &testa_obj) ;

/** La funzione immetti_prestito serve per, dati un ID utente e un ID risorsa, 
  * concedere il prestito della risorsa richiesta all'utente designato.
  * Finestre di errore vengono mostrate nei casi in cui: non ci siano utenti,
  * non ci siano risorse o essi non vengano trovati. In caso contrario si cambia 
  * lo stato della risorsa richiesta da libera a occupata e si associa ad essa 
  * l'ID dell'utente che la detiene in prestito.
  */
void immetti_prestito (lista_obj &testa_obj, lista_people &testa_people) ;

/** Funzione che libera una risorsa occupata da un prestito.
  * Dopo aver rilevato dalla Entry l'ID della risorsa da liberare, essa viene 
  * cercata tramite la funzione ::cerca_elem_id . Se l'elemento non viene 
  * trovato si apre una finestra di erore, altrimenti si aggiorna lo stato della
  * risorsa e se ne azzera il campo id_actual_user. Nel caso in cui la risorsa
  * venisse trovata ma fosse libera viene mostrata una finestra di errore.
  */
void ritorna_prestito (lista_obj &testa_obj) ;

/** La funzione proroga_prestito permette di allungare la data di rientro del 
  * prestito in atto di un mese dal giorno di richiesta.
  * Viene prelevato l'ID della risorsa di cui prorogare il prestito dalla Entry,
  * convertito in int tramite la funzione di libreria atoi e poi passato alla 
  * funzione ::cerca_elem_id. Se la risorsa viene trovata ed è occupata il 
  * prestito viene prorogato di un mese dalla data corrente tramite la funzione
  * ::calcola_restituzione , altrimenti vengono mostrate finestre di errore 
  * opportune. 
  */
void proroga_prestito (lista_obj &testa_obj) ;

/* Fine interfaccia del modulo Operazioni/Ricerca */
