
#include <iostream>
#include <ctime>
#include <string.h>
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <gtk/gtk.h>
#include <cassert>

using namespace std;

#include "struttura_dati.h"
#include "inserisci_elimina.h"
#include "operazioni_ricerca.h"

extern GtkBuilder *builder;

// Inizio definizioni delle funzioni del modulo Inserisci/Elimina
 
void mostra_error_alert (const char *str1);
                   
void leggi_riga (istream &is, char *riga )
  { while ( is.peek()=='\n')      
      is.get() ;
    is.get (riga, max_c);
    is.get();
   }                

void ins_obj (lista_obj &testa_obj)
{   
    elem_obj *o = new elem_obj ;
    
    GtkEntry *entry17 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry17")) ;
    const char *titolo =
    gtk_entry_get_text(entry17);
    strcpy(o->title, titolo);

    GtkEntry *entry18 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry18")) ;
    const char *cognome_autore =
    gtk_entry_get_text(entry18);
    strcpy(o->author_surname, cognome_autore);

    GtkEntry *entry19 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry19")) ;
    const char *nome_autore =
    gtk_entry_get_text(entry19);
    strcpy(o->author_name, nome_autore);

    GtkEntry *entry20 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry20")) ;
    const char *giorno =
    gtk_entry_get_text(entry20);
    o->rel_date.tm_mday = atoi(giorno) ;
    if (o->rel_date.tm_mday<0 || o->rel_date.tm_mday>32)
     { mostra_error_alert(" I giorni vanno da 1 a 31, inserimento fallito ");
       return ;
      }
    
    GtkEntry *entry22 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry22")) ;
    const char *mese =
    gtk_entry_get_text(entry22);
    o->rel_date.tm_mon = atoi(mese) ;
    if (o->rel_date.tm_mon<0 || o->rel_date.tm_mon>13)
     { mostra_error_alert(" I mesi vanno da 1 a 12, inserimento fallito ");
       return ;
     } 
    
    --o->rel_date.tm_mon ;

    GtkEntry *entry23 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry23")) ;
    const char *anno =
    gtk_entry_get_text(entry23);
    o->rel_date.tm_year = atoi(anno) ;
  
    GtkEntry *entry21 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry21")) ;
    const char *casa_editrice =
    gtk_entry_get_text(entry21);
    strcpy(o->manifacturer, casa_editrice);

    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton11"))))
     o->type = 0 ;
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton12"))))
     o->type = 1 ; 
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton13")))) 
     o->type = 2 ;
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton14"))))
     o->type = 3 ;
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton15"))))
     o->type = 4 ; 

    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton16"))))
     o->category = 0 ;
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton17"))))
     o->category = 1 ; 
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton18")))) 
     o->category = 2 ;
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton19"))))
     o->category = 3 ;
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton20"))))
     o->category = 4 ;
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton21"))))
     o->category = 5 ;
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton22"))))
     o->category = 6 ; 
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton23")))) 
     o->category = 7 ;
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton24"))))
     o->category = 8 ;
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton25"))))
     o->category = 9 ;
    if (gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton26"))))
     o->category = 10 ;
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton27"))))
     o->category = 11 ; 
    else if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(gtk_builder_get_object(builder, "radiobutton28")))) 
     o->category = 12 ;
                  
    o->id = last_id_obj ;

    if (o->id == 0 )
      ++o->id;

    ++last_id_obj ;

    o->status = 0 ; 
    o->id_actual_user = 0;

    o->pun = testa_obj ;                
    testa_obj = o ;

    D2(cout<<" Titolo e categoria del nuovo elemento alla fine di ins_obj "<<o->title<<"-"<<o->category<<endl);
    	
}

void ins_people(lista_people &testa_people) 
{    D1(cout<<" Indirizzo di testa_people dentro a ins_people"<<&testa_people<<endl);

    elem_people *p = new elem_people ;
    
    GtkEntry *entry1 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry1")) ;
    const char *nome_utente =
    gtk_entry_get_text(entry1);

    GtkEntry *entry2 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry2")) ;
    const char *cognome_utente =
    gtk_entry_get_text(entry2);

    GtkEntry *entry3 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry3")) ;
    const char *telefono =
    gtk_entry_get_text(entry3);

    GtkEntry *entry4 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry4")) ;
    const char *anno =
    gtk_entry_get_text(entry4);
 
    strcpy (p->user_name, nome_utente);
    strcpy (p->user_surname, cognome_utente);
    p->n_telefono = atol(telefono);
    p->birth_year = atoi(anno);      
    p->id = last_id_people;
     
     if (p->id == 0 )
       ++p->id;

     last_id_people++;
     cout<<" ID IDENTIFICATIVO DELL'UTENTE : "<<p->id<<endl;

     p->pun_p = testa_people ;
     testa_people = p ;

     D1(cout<<"Indirizzo di testa_people dentro a ins_people alla fine"<<&testa_people<<endl);     
}


elem_obj* elimina_obj(lista_obj &testa_obj)
{   
    elem_obj *p = testa_obj ;

    elem_obj *prec = new elem_obj ;

    GtkEntry *entry5 = GTK_ENTRY(gtk_builder_get_object(builder, "entry5")) ;
    const char *id_obj =
    gtk_entry_get_text(entry5); 
    int elimina = atoi(id_obj);
 
    if ( p == 0 )
     return testa_obj;

    while (p->pun != 0 && p->id != elimina )
      { prec = p ;
        p = p->pun ;
      } 
    
    if (p == testa_obj && p->pun == 0)
     { delete [] p;

       lista_obj testa_new = new elem_obj ;
       testa_new = 0 ;
 
       last_id_obj = 0;
       return testa_new;
     }

    if ( p == testa_obj )
     { testa_obj = testa_obj->pun ;
       delete [] p ;

       return testa_obj;
      } 

     if (p->pun == 0)
          { prec->pun = 0 ; 
            delete [] p;

            return testa_obj;
           }
     
     prec->pun = p->pun ;
     delete []p ;
    
     return testa_obj;
}

elem_people* elimina_people(lista_people &testa_people)
{
    elem_people *p = testa_people ;

    GtkEntry *entry14 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry14")) ;
    const char *id_utente =
    gtk_entry_get_text(entry14);
    int elimina = atoi(id_utente); 

    elem_people *prec = new elem_people ;

    if (p == 0)
	return testa_people ;

    while (p->pun_p != 0 && p->id != elimina )
      { prec = p ;
        p = p->pun_p ;
      } 
    if ( p == 0 )
     return testa_people;

    if (p == testa_people && p->pun_p == 0)
     { delete [] p;

       lista_people testa_new = new elem_people ;
       testa_new = 0 ;
 
       last_id_people = 0;

       D1(cout<<"Indirizzo di testa_new (nuovo testa_people) dentro a elimina_people "<<&testa_new<<endl);

       return testa_new;
     }
  
    if ( p == testa_people )
     { testa_people = testa_people->pun_p ;
       delete [] p ;
       return testa_people;
      } 
 
     if (p->pun_p == 0)
          { prec->pun_p = 0 ; 
            delete [] p;

            return testa_people;
           }

     prec->pun_p = p->pun_p ;
     delete []p ;

     
     return testa_people;

}

// Fine definizioni delle funzioni del modulo Inserisci/Elimina


