/* Inizio header del modulo Inserisci/Elimina */

// Il modulo Inserisci/Elimina non ha una struttura dati propria 

/* Inizio interfaccia del modulo Inserisci/Elimina */

// Funzioni 

/** Funzione che legge una riga con spazi. */
void leggi_riga (istream &is, char *riga ) ;

/** Funzione per inserire una nuova risorsa nella mediateca.
  * Alloco il nuovo elemento della lista.
  * Per ogni campo da inserire manualmente copio il testo dalla stringa 
  * letta dalla entry al campo corrispondente del nuovo elemento. Per i 
  * campi da inserire tramite radiobutton faccio corrispondere ad ogni 
  * radiobutton con relativa label il valore attribuito dal programmatore.
  * Dato che il tipo di dato .tm_mon va da 0 a 11 devo decrementare di 1 il 
  * valore inserito dall'utente che sarà tra 1 e 12. Inoltre per i campi 
  * numerici è necessario fare la conversione di tipo tramite atoi.
  */
void ins_obj (lista_obj &testa_obj) ;

/** Funzione che data la testa della lista alloca un nuovo elemento della lista 
  * e lo mette in testa ad essa. I parametri dell'utente da inserire vengono 
  * prelevati dalle entry e, se necessario, opportunamente convertiti ad int o 
  * long int tramite le funzioni di libreria atoi e atol. L'ID associato ad ogni 
  * nuovo utente è progressivo e univoco. Gli ID partono da 1. 
  * Nel caso in cui ci sia stata un eliminazione totale della lista in 
  * precedenza questo if fa si che l'ID del primo elemento venga posto ad 1 
  * e non al precedente numero di last_id_people. Vedi ::elimina_people.
  */
void ins_people(lista_people &testa_people) ;

/** Funzione che elimina dalla lista una risorsa di cui è dato l'ID. 
  * La funzione prende in ingresso la testa della lista e ritorna l'indirizzo 
  * alla testa della lista, questo perchè nel caso vengano eliminati tutti gli 
  * elementi della lista viene inizializzata una nuova testa della lista. 
  * Il funzionamento della funzione è il seguente: viene creato un puntatore per 
  * scorrere la lista, p, poi viene allocato un elemento ausiliario prec che 
  * serve per scorrere la lista e agganciare gli elementi dato che la lista è 
  * semplice. Quindi si preleva dalla entry5 il valore dell'ID da eliminare, lo
  * si converte a int tramite la funzione atoi e : se la lista è vuota si esce 
  * dalla funzione, se l'id attuale è diverso da quello cercato e l'elemento non 
  * è l'ultimo si scorre la lista fino a che o si arriva all'ultimo elemento o 
  * l'elemento cercato viene trovato. Se l'elemento trovato è l'unico della 
  * lista lo si dealloca, si alloca una nuova testa della lista e si riporta 
  * last_id_obj a 0. Se l'elemento da eliminare è in testa alla lista setto il 
  * valore della nuova testa (l'elemento puntato da testa_obj), dealloco la 
  * vecchia testa della lista e restituisco la nuova testa della lista. 
  * Se l'elemento da eliminare è in fondo alla lista setto a 0 il puntatore
  * del penultimo elemento della lista e poi dealloco l'elemento da da eliminare.
  * Se l'elemento da eliminare si trova in mezzo alla lista prima di 
  * deallocarlo si aggancia il puntatore del precedente a quello del 
  * successivo e a questo punto si può deallocare l'elemento desiderato, 
  * ritornando infine il puntatore alla testa della lista. 
  */
elem_obj* elimina_obj(lista_obj &testa_obj) ;

/** Funzione che prende in ingresso la testa della lista degli utenti e dato l'
  * ID dell'utente da eliminare tramite la Entry lo converte ad int, lo cerca e,
  * se presente, lo elimina.   
  */
elem_people* elimina_people(lista_people &testa_people) ;

/* Fine interfaccia del modulo Inserisci/Elimina */
