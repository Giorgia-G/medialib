#include <iostream>
#include <ctime>
#include <gtk/gtk.h>
#include <string.h>
#include <sstream>
#include <cstdlib>
#include <fstream>
#include <cassert>

using namespace std;

#include "struttura_dati.h"
#include "operazioni_ricerca.h"
#include "caricamento_salvataggio.h"
#include "inserisci_elimina.h"

extern GtkBuilder *builder;

// Inizio definizioni delle funzioni del modulo Caricamento/Salvataggio

/** Funzione che legge una riga contenente spazi 
  */
void leggi_riga_f (istream &is, char *riga )
{
int k = 0;
    while (is.peek() == ';' || is.peek()=='\n' || is.peek() == '/')
      is.get() ;
while (is.peek() != ';' && is.peek()!=-1 && is.peek() != '/')
           is.get (riga[k++]);
riga[k] = '\0';
   }  

void salva_obj (lista_obj &testa_obj, ostream &os)
{ 
  elem_obj *p = testa_obj ;

  os<<(last_id_obj-1)<<endl;

  while (p != 0) 
     {
		os<<p->title<<";"<<p->author_name<<";"<<p->author_surname<<";"<<p->rel_date.tm_mday<<"/"<<p->rel_date.tm_mon<<"/"
          <<p->rel_date.tm_year<<";"<<p->manifacturer<<";"<<p->type<<";"<<p->category<<";"<<p->id<<";"
          <<p->status<<";";

        if (p->status == 1)
          os<<p->id_actual_user<<";";
        
        os<<endl ;
       
        p=p->pun;
	  }
	
}

void carica_obj (lista_obj &testa_obj)
{ ifstream f(NOME_FILE_OBJ);
 
  assert (f);
   
   f>>last_id_obj;
   last_id_obj = 1+last_id_obj;

  for (int i=1; i<last_id_obj;i++)    
   { 
     elem_obj *o = new elem_obj ;
            
     leggi_riga_f(f, o->title);       
     leggi_riga_f(f, o->author_name);
     leggi_riga_f(f, o->author_surname);    
     char data[70] = "";
     leggi_riga_f(f, data);
     o->rel_date.tm_mday = atoi(data);
     leggi_riga_f(f, data);
     o->rel_date.tm_mon = atoi(data);
     leggi_riga_f(f, data);
     o->rel_date.tm_year = atoi(data);                
     leggi_riga_f(f, o->manifacturer); 
     leggi_riga_f(f, data);
     o->type = atoi(data);                 
     leggi_riga_f(f, data);
     o->category = atoi(data);          
     leggi_riga_f(f, data);
     o->id = atoi(data);    
     leggi_riga_f(f, data);
     o->status = atoi(data);             

            if (o->status == 1)
             { leggi_riga_f(f, data);
               o->id_actual_user = atoi(data); }
            else 
              o->id_actual_user = 0;

     o->pun = testa_obj ;                
     testa_obj = o ;

   }
}

void salva_people (lista_people &testa_people, ostream &os)
{ 
  elem_people *p = testa_people ;

  os<<(last_id_people-1)<<endl;

  while (p != 0) 
     {
		os<<p->user_surname<<";"<<p->user_name<<";"
          <<p->n_telefono<<";"<<p->birth_year<<";"
          <<p->id<<";";
        
        os<<endl ;
       
        p=p->pun_p;
	  }
	
}

void carica_people (lista_people &testa_people)
{ ifstream fp(NOME_FILE_PEO);

  assert(fp);
     
  fp>>last_id_people;
  last_id_people = 1+last_id_people;

  for (int i=1; i<last_id_people;i++)    
   { 
     elem_people *o = new elem_people ;
            
     leggi_riga_f(fp, o->user_surname);       
     leggi_riga_f(fp, o->user_name);
     char n[70] = "";
     leggi_riga_f(fp, n);
     o->n_telefono = atoi(n);
     leggi_riga_f(fp, n);
     o->birth_year = atoi(n);
     leggi_riga_f(fp, n);
     o->id = atoi(n);

     o->pun_p = testa_people ;                
     testa_people = o ;

   }
}
