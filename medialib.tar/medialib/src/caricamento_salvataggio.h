/* Inizio header del modulo Caricamento/Salvataggio */

// Il modulo Caricamento/Salvataggio non ha una struttura dati propria

// Inizio funzioni del modulo Caricamento/Salvataggio

/** Funzione che salva la lista delle risorse sul file NOME_FILE_OBJ.txt 
  */
void salva_obj (lista_obj &testa_obj, ostream &os) ;

/** Funzione che carica dal file NOME_FILE_OBJ.txt la lista delle risorse
  */
void carica_obj (lista_obj &testa_obj) ;

/** Funzione che salva sul file NOME_FILE_PEO.txt la lista degli utenti.
  */
void salva_people (lista_people &testa_people, ostream &os) ;

/** Funzione che carica dal file NOME_FILE_PEO.txt la lista degli utenti
  */
void carica_people (lista_people &testa_people) ;

// Fine definizioni delle funzioni del modulo Caricamento/Salvataggio

