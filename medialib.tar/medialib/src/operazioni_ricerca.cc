
#include <iostream>
#include <ctime>
#include <gtk/gtk.h>
#include <string.h>
#include <sstream>
#include <stdlib.h>
#include <fstream>
#include <cassert>

using namespace std;

#include "struttura_dati.h"
#include "inserisci_elimina.h"

extern GtkBuilder *builder;

/** Funzione che serve per mostrare, a seconda dei vari errori possibili in ogni
  * funzione, una finsetra con un messaggio di errore diverso passato come 
  * stringa alla funzione.
  */
void mostra_error_alert (const char *str1)
{
    GtkLabel *label_principale = GTK_LABEL(gtk_builder_get_object(builder, "label_principale")) ;
    gtk_label_set_text(label_principale, str1);

    GtkWidget *error_alert = GTK_WIDGET(gtk_builder_get_object(builder, "error_alert")) ;
    gtk_widget_show_all(error_alert) ;
}

/** Funzione calcola la data di rientro di una risorsa.
  * Per fare ciò si inizializza ltm alla data del giorno corrente e si aggiunge 
  * un mese ovvero la durata del prestito.
  */
tm* calcola_restituzione ()
{   
     time_t ct;
  	 ct = time(NULL);
     struct tm *ltm ;
     ltm = localtime(&ct) ;
  
     ltm->tm_year = 1900 + ltm->tm_year ;

     if (ltm->tm_mon == 11)
      { ltm->tm_mon = 0 ;
        ltm->tm_year = ltm->tm_year +1  ; }
     else
        ltm->tm_mon = ltm->tm_mon +1 ;
  
     return ltm ;
}

/** Funzione che inizialmente prende in ingresso la testa della lista delle 
  * risorse e l'ID della risorsa da trovare. In modo ricorsivo la funzione cerca 
  * l'elemento con ID corrispondente nella lista. Se l'elemento viene trovato il 
  * valore di ritorno è appunto il puntatore all'indirizzo dell'elemento cercato,
  * altrimenti la funzione richiama se stessa ma passando al posto della testa 
  * della lista il riferimento all'elemento successivo. Se l'ID dell'elemento in 
  * analisi è diverso da quello cercato e il puntatore al prossimo elemeto è 0 
  * allora viene ritornato come valore in uscita un puntatore a NULL. 
  */
elem_obj* cerca_elem_id (lista_obj &testa_obj, int cod_r)
{  elem_obj *not_find = NULL ;
   if (testa_obj->id == cod_r ) 
    return testa_obj ; 
   else 
    { if (testa_obj->pun != 0 )
       return cerca_elem_id (testa_obj->pun, cod_r);
      else
       return not_find;
       
     }
}

/** Funzione che inizialmente prende in ingresso la testa della lista degli 
  * utenti e l'ID dell'utente da trovare. In modo ricorsivo la funzione cerca 
  * l'elemento con ID corrispondente nella lista. Se l'elemento viene trovato il 
  * valore di ritorno è appunto il puntatore all'indirizzo dell'elemento cercato,
  * altrimenti la funzione richiama se stessa ma passando al posto della testa 
  * della lista il riferimento all'elemento successivo. Se l'ID dell'elemento in 
  * analisi è diverso da quello cercato e il puntatore al prossimo elemeto è 0 
  * allora viene ritornato come valore in uscita un puntatore a NULL. 
  */
elem_people* cerca_people_id (lista_people &testa_people, int id)
{  elem_people *not_find = NULL ;
   if (testa_people->id == id ) 
    return testa_people ; 
   else 
    { if (testa_people->pun_p != 0 )
       return cerca_people_id (testa_people->pun_p, id);
      else 
       return not_find;
       
    }
}

/** La funzione ha lo scopo, data una stringa che rappresenta un titolo da 
  * cercare e il puntatore alla testa della lista delle risorse, di ritornare il
  * puntatore all'elemento cercato se esiste, altrimenti ritorna un puntatore a 
  * NULL. Per fare ciò sfrutta il risultato della strcmp che restituisce 0 se le 
  * stringhe sono uguali. Se quindi val=0 viene ritornato l'indirizzo cercato, 
  * in caso contrario se il puntatore al prossimo elemento è diverso da 0, 
  * la funzione richiama se stessa ma passando anzichè la testa della lista il 
  * puntatore al prossimo elemento; se val è diverso da 0 ma il puntatore al 
  * prossimo elemento è 0 allora viene ritornato il puntatore nullo.
  */
elem_obj* cerca_elem_titolo (const lista_obj &testa_obj, const char *str)  
{ 
  elem_obj * not_find = NULL ;

  int val = strcmp (testa_obj->title, str ) ;
  if (!val )
   return testa_obj ;
  else 
   { if (testa_obj->pun != 0 )
      return cerca_elem_titolo (testa_obj->pun, str); 
     else
      return not_find;
   }
}

/** La funzione ha lo scopo, date due stringhe corrispondenti a nome e cognome da 
  * cercare e il puntatore alla testa della lista degli utenti, di ritornare il
  * puntatore all'elemento cercato se esiste, altrimenti ritorna un puntatore a 
  * NULL. Per fare ciò sfrutta il risultato della strcmp che restituisce 0 se le 
  * stringhe sono uguali. Se quindi val=0 viene ritornato l'indirizzo cercato, 
  * in caso contrario se il puntatore al prossimo elemento è diverso da 0, 
  * la funzione richiama se stessa ma passando anzichè la testa della lista il 
  * puntatore al prossimo elemento; se val è diverso da 0 ma il puntatore al 
  * prossimo elemento è 0 allora viene ritornato il puntatore nullo.
  */
elem_people* cerca_people_cognome_nome (const lista_people &testa_people,const char *cognome,const char *nome)
{
  elem_people *not_find = NULL ;
  
  int val = (strcmp ( testa_people->user_surname, cognome ) ) || (strcmp (testa_people->user_name, nome));
  if (!val )
     return testa_people ;
  else 
   { if (testa_people->pun_p != 0 )
      return cerca_people_cognome_nome (testa_people->pun_p, cognome, nome); 
     else 
      return not_find;
    }
}

void cerca_people_nominativo(lista_people &testa_people)
{   if (last_id_people<2)
    { mostra_error_alert(" La mediateca è vuota: impossibile stampare utente");
      return ; }

    ostringstream oss ;

    GtkEntry *entry13 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry13")) ;
    const char *nome =
    gtk_entry_get_text(entry13);    

    GtkEntry *entry12 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry12")) ;
    const char *cognome =
    gtk_entry_get_text(entry12);

    elem_people *cercato = cerca_people_cognome_nome(testa_people, cognome, nome);
  
    if (cercato != NULL)
     { GtkTextView *textview_user =
	   GTK_TEXT_VIEW(gtk_builder_get_object(builder, "textview1")) ;   
       GtkTextBuffer *buffer = 
	   gtk_text_view_get_buffer(textview_user) ;

        
       oss<<" Cognome : "<<cercato->user_surname<<endl
          <<" Nome : "<<cercato->user_name<<endl
          <<" Numero di telefono: "<<cercato->n_telefono<<endl
          <<" Anno di nascita : "<<cercato->birth_year<<endl
    	  <<" ID : "<<cercato->id<<endl;

       gtk_text_buffer_set_text(buffer, oss.str().c_str(), -1) ;
      }  
    else 
     mostra_error_alert ("Utente non presente nel sistema");
}

void modifica_utente (lista_people &testa_people)
{   D1(cout<<"Indirizzo di testa_people dentro a modifica_utente"<<&testa_people<<endl);

    GtkEntry *entry11 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry11")) ;
    const char *id_mod =
    gtk_entry_get_text(entry11);    

    GtkEntry *entry10 = 
	GTK_ENTRY(gtk_builder_get_object(builder, "entry10")) ;
    const char *tel_new =
    gtk_entry_get_text(entry10);

    int u_id;
    u_id = atoi(id_mod);
        
    lista_people cercato = cerca_people_id (testa_people, u_id) ;
 
    if (cercato != NULL)
     cercato->n_telefono = atol(tel_new) ;  
    else 
     mostra_error_alert("Modifica impossibile : l'utente cercato non esistente");                     
}

void stampa_obj_per_titolo (lista_obj &testa_obj)
{  
   if (last_id_obj<2)
    { mostra_error_alert(" La mediateca è vuota: impossibile stampare elementi");
      return ; }

   GtkEntry *entry6 = GTK_ENTRY(gtk_builder_get_object(builder, "entry6")) ;
   const char *str = gtk_entry_get_text(entry6);
  

   elem_obj *cercato = cerca_elem_titolo (testa_obj, str) ; 

  if (cercato != NULL)
 { GtkTextView *textview_risorsa = GTK_TEXT_VIEW(gtk_builder_get_object(builder, "textview2")) ;   
   GtkTextBuffer *buffer = gtk_text_view_get_buffer(textview_risorsa) ;

   ostringstream os ;
   os<<" Titolo : "<<cercato->title<<endl
     <<" Cognome autore : "<<cercato->author_surname<<endl
     <<" Nome autore : "<<cercato->author_name<<endl
     <<" Data di rilascio : "<<cercato->rel_date.tm_mday<<"/"<<cercato->rel_date.tm_mon<<"/"<<cercato->rel_date.tm_year<<endl
     <<" Casa editrice : "<<cercato->manifacturer<<endl
     <<" Tipologia risorsa: ";
       
     /* Tramite questo switch trasformo il numero scelto 
        per rappresentare il tipo della risorsa e la "converto" a un messaggio più
        user-friendly, ovvero parole semplici e chiare. 
      */
     switch(cercato->type) {
		case 0: { os<<"libro"<<endl ; 
                    break ;
                   };
        case 1: { os<<"ebook"<<endl ; 
                    break ;
                   }
        case 2: { os<<"dvd"<<endl ; 
                    break ;
                   }
        case 3: { os<<"cd"<<endl ;  
                    break ;
                   }
        case 4: { os<<"rivista"<<endl ;  
                    break ;
                   }
                  } 
   os<<"Categoria risorsa : ";
      /* Tramite questo switch trasformo la lettera-simbolo scelta dal bibliotecario 
         per rappresentare la categoria della risorsa e la "converto" al tipo di dato 
         enum, scleto per evitare errori nella registrazione di nuove risorse.
       */
     switch(cercato->category) {
		case 0: { os<<"narrativa primo ciclo"<<endl ; 
                    break ;
                   };
        case 1: { os<<"narrativa secondo ciclo"<<endl ; 
                    break ;
                   }

        case 2: { os<<"narrativa terzo ciclo"<<endl ;  
                    break ;
                   }
        case 3: { os<<"albo illustrato"<<endl ; 
                    break ;
                   }
        case 4: { os<<"storia"<<endl ; 
                    break ;
                   }
        case 5: { os<<"geografia"<<endl ; 
                    break ;
                   };
        case 6: { os<<"scienze"<<endl ;
                    break ;
                   }
        case 7: { os<<"arte"<<endl ; 
                    break ;
                   }
        case 8: { os<<"intercultura"<<endl ;
                    break ;
                   }
        case 9: { os<<" libri per insegnanti"<<endl ; 
                    break ;
                   }
        case 10: { os<<"francese"<<endl ; 
                    break ;
                   };
        case 11: { os<<"inglese"<<endl ;
                    break ;
                   }
        case 12: { os<<"tecnologia informatica"<<endl ;
                    break ;
                   }
                  }

      os<<"ID risorsa : "<<cercato->id<<endl
        <<"Stato risorsa : ";
        if (cercato->status==0)
         os<<" libero"<<endl;
        else
         { os<<" occupato "<<endl;
           os<<"ID dell'user che ha attualmente la risorsa : "<<cercato->id_actual_user<<endl;
           os<<"Data rientro risorsa : "<<cercato->return_date->tm_mday<<"/"<<++(cercato->return_date->tm_mon)<<"/"<<cercato->return_date->tm_year<<endl;
          }
     gtk_text_buffer_set_text(buffer, os.str().c_str(), -1) ;
   }
 if (cercato == NULL)
  mostra_error_alert("La risorsa non è presente nel sistema ");
} 
 
void immetti_prestito (lista_obj &testa_obj, lista_people &testa_people)
{  if (last_id_obj<1)
    mostra_error_alert ("Prestito impossibile : nessuna risorsa registrata nel sistema");
  
   if (last_id_people<1)
    mostra_error_alert ("Prestito impossibile : nessun utente registrato nel sistema");

   int cod_u, cod_r ;
   
   GtkEntry *entry7 = GTK_ENTRY(gtk_builder_get_object(builder, "entry7")) ;
   const char *id_u = gtk_entry_get_text(entry7);
   cod_u = atoi(id_u) ;

   elem_people *cercato_u = cerca_people_id (testa_people, cod_u) ;

   GtkEntry *entry8 = GTK_ENTRY(gtk_builder_get_object(builder, "entry8")) ;
   const char *id_r = gtk_entry_get_text(entry8);
   cod_r = atoi(id_r) ;

   elem_obj *cercato = cerca_elem_id (testa_obj, cod_r) ;
   
   if (cercato == NULL) 
    mostra_error_alert ("Prestito impossibile : risorsa non esistente");

   if (cercato_u == NULL)
    mostra_error_alert("Prestito impossibile : utente non esistente ");

  if (cercato->status == 0)
   { cercato->status = 1 ;
     cercato->id_actual_user = cod_u ;
     
     cercato->return_date = calcola_restituzione () ; 
     return ;
     }
}

void ritorna_prestito (lista_obj &testa_obj)
{ int tmp ;
  GtkEntry *entry15 = GTK_ENTRY(gtk_builder_get_object(builder, "entry15")) ;
  const char *id_r = gtk_entry_get_text(entry15);
  tmp = atoi(id_r) ;

  elem_obj *cercato = cerca_elem_id (testa_obj, tmp) ;
  if (cercato == NULL)
   { mostra_error_alert("Restituzione impossibile : risorsa non esistente ");
     return ; 
   }

  if (cercato->status == 1)
  { cercato->id_actual_user = 0 ; 
    cercato->status = 0; }
  else 
    mostra_error_alert("Restituzione impossibile : risorsa attualmente non in prestito ");  
} 

void proroga_prestito (lista_obj &testa_obj)
{
  int tmp;
  GtkEntry *entry16 = GTK_ENTRY(gtk_builder_get_object(builder, "entry16")) ;
  const char *id_r = gtk_entry_get_text(entry16);
  tmp = atoi(id_r) ;

  elem_obj *cercato = cerca_elem_id (testa_obj, tmp);

  if (cercato == NULL)
   { mostra_error_alert("Proroga impossibile : risorsa non esistente");
     return ; 
   }
  else 
   { if (cercato->status==1)
     { cercato->return_date = calcola_restituzione() ;

       GtkTextView *textview_pro = GTK_TEXT_VIEW(gtk_builder_get_object(builder, "textview3")) ;   
       GtkTextBuffer *buffer = gtk_text_view_get_buffer(textview_pro) ;

       ostringstream ost;
       ost<<" Prestito prorogabile di un mese da oggi. \n La nuova data di ritorno è : "
          <<cercato->return_date->tm_mday<<"/"<<cercato->return_date->tm_mon
          <<"/"<<cercato->return_date->tm_year <<endl;
 
       gtk_text_buffer_set_text(buffer, ost.str().c_str(), -1) ; 
     } 
     else 
      mostra_error_alert("Proroga impossibile : risorsa non in prestito");
      
   }   
}

