var searchData=
[
  ['manifacturer',['manifacturer',['../structelem__obj.html#a2c87da19d2a6463abb7f68480181db06',1,'elem_obj']]],
  ['max_5fc',['max_c',['../struttura__dati_8h.html#a95a8fb82c8b29aed9827612358a2017d',1,'struttura_dati.h']]]
];
