var searchData=
[
  ['elem_5fobj',['elem_obj',['../structelem__obj.html',1,'']]],
  ['elem_5fpeople',['elem_people',['../structelem__people.html',1,'']]],
  ['elimina_5fobj',['elimina_obj',['../inserisci__elimina_8cc.html#a36f952a7165433ea80ad62448bfee286',1,'elimina_obj(lista_obj &amp;testa_obj):&#160;inserisci_elimina.cc'],['../inserisci__elimina_8h.html#a36f952a7165433ea80ad62448bfee286',1,'elimina_obj(lista_obj &amp;testa_obj):&#160;inserisci_elimina.cc']]],
  ['elimina_5fpeople',['elimina_people',['../inserisci__elimina_8cc.html#a866ce2c0c7ef1bd1bc080c1066fc2668',1,'elimina_people(lista_people &amp;testa_people):&#160;inserisci_elimina.cc'],['../inserisci__elimina_8h.html#a866ce2c0c7ef1bd1bc080c1066fc2668',1,'elimina_people(lista_people &amp;testa_people):&#160;inserisci_elimina.cc']]],
  ['elimina_5frisorsa',['elimina_risorsa',['../MediaLib_8cc.html#af849463c6a44f07dd68e4f2a3269fbd3',1,'MediaLib.cc']]],
  ['elimina_5frisorsa_5finsert',['elimina_risorsa_insert',['../MediaLib_8cc.html#ab668640b6fa9e5cfa214117c4322b4b9',1,'MediaLib.cc']]],
  ['elimina_5fuser',['elimina_user',['../MediaLib_8cc.html#a758e2cb0da9ac08cacf675435fb6c651',1,'MediaLib.cc']]],
  ['elimina_5fuser_5finsert',['elimina_user_insert',['../MediaLib_8cc.html#aa97b1e7a43a74557a59e407d4ce8851c',1,'MediaLib.cc']]]
];
