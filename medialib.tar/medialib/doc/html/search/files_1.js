var searchData=
[
  ['inserisci_5felimina_2ecc',['inserisci_elimina.cc',['../inserisci__elimina_8cc.html',1,'']]],
  ['inserisci_5felimina_2eh',['inserisci_elimina.h',['../inserisci__elimina_8h.html',1,'']]]
];
