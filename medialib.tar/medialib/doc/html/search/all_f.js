var searchData=
[
  ['user_5fname',['user_name',['../structelem__people.html#a2dda724078fecfa7654bb05c6280d507',1,'elem_people']]],
  ['user_5fsurname',['user_surname',['../structelem__people.html#ab892738f3397368b936a2feeecd9eff5',1,'elem_people']]]
];
