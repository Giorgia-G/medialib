var searchData=
[
  ['leggi_5friga',['leggi_riga',['../inserisci__elimina_8cc.html#a75dc118355081110a2dce486cc459968',1,'leggi_riga(istream &amp;is, char *riga):&#160;inserisci_elimina.cc'],['../inserisci__elimina_8h.html#a75dc118355081110a2dce486cc459968',1,'leggi_riga(istream &amp;is, char *riga):&#160;inserisci_elimina.cc']]],
  ['leggi_5friga_5ff',['leggi_riga_f',['../caricamento__salvataggio_8cc.html#ad6d37e75be8e40bcd7317f2dd94dce32',1,'caricamento_salvataggio.cc']]]
];
