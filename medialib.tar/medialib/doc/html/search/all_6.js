var searchData=
[
  ['id',['id',['../structelem__obj.html#a40e16d76dcc9762772246160c28c01cd',1,'elem_obj::id()'],['../structelem__people.html#a8b2992b6d08fe9f72c8d7afb254e195a',1,'elem_people::id()']]],
  ['id_5factual_5fuser',['id_actual_user',['../structelem__obj.html#ab1c62bf13d8a8ddf8b7a07ffc0f82e18',1,'elem_obj']]],
  ['immetti_5fprestito',['immetti_prestito',['../operazioni__ricerca_8cc.html#a63d9b0e2ec0bcdd4564cc0101273bd2f',1,'immetti_prestito(lista_obj &amp;testa_obj, lista_people &amp;testa_people):&#160;operazioni_ricerca.cc'],['../operazioni__ricerca_8h.html#a63d9b0e2ec0bcdd4564cc0101273bd2f',1,'immetti_prestito(lista_obj &amp;testa_obj, lista_people &amp;testa_people):&#160;operazioni_ricerca.cc']]],
  ['ins_5fobj',['ins_obj',['../inserisci__elimina_8cc.html#a0df517ef19a801200d79f084be32c62f',1,'ins_obj(lista_obj &amp;testa_obj):&#160;inserisci_elimina.cc'],['../inserisci__elimina_8h.html#a0df517ef19a801200d79f084be32c62f',1,'ins_obj(lista_obj &amp;testa_obj):&#160;inserisci_elimina.cc']]],
  ['ins_5fpeople',['ins_people',['../inserisci__elimina_8cc.html#a8f190ba54f31d351a4eb41dacd9d2b22',1,'ins_people(lista_people &amp;testa_people):&#160;inserisci_elimina.cc'],['../inserisci__elimina_8h.html#a8f190ba54f31d351a4eb41dacd9d2b22',1,'ins_people(lista_people &amp;testa_people):&#160;inserisci_elimina.cc']]],
  ['inserisci_5felimina_2ecc',['inserisci_elimina.cc',['../inserisci__elimina_8cc.html',1,'']]],
  ['inserisci_5felimina_2eh',['inserisci_elimina.h',['../inserisci__elimina_8h.html',1,'']]],
  ['inserisci_5frisorsa',['inserisci_risorsa',['../MediaLib_8cc.html#a78fb8e27c4a18ed83f77bb3e28f5d2de',1,'MediaLib.cc']]],
  ['inserisci_5frisorsa_5finsert',['inserisci_risorsa_insert',['../MediaLib_8cc.html#a7dfe64e550dd6890d383228b8262077c',1,'MediaLib.cc']]],
  ['inserisci_5ftel',['inserisci_tel',['../MediaLib_8cc.html#aa6554e929813629933724c7c6af0f97e',1,'MediaLib.cc']]],
  ['inserisci_5ftel_5finsert',['inserisci_tel_insert',['../MediaLib_8cc.html#a9ff64fa3e4e5e825ca7e1e7625a0a592',1,'MediaLib.cc']]],
  ['inserisci_5fuser',['inserisci_user',['../MediaLib_8cc.html#afc4ab299bd9c0efbb732181552667ba2',1,'MediaLib.cc']]],
  ['inserisci_5fuser_5finsert',['inserisci_user_insert',['../MediaLib_8cc.html#a2dce2178bfd1ecfc24a0627d7f363733',1,'MediaLib.cc']]]
];
