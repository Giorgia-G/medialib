var searchData=
[
  ['last_5fid_5fobj',['last_id_obj',['../MediaLib_8cc.html#a43b124c8cd8b452d9b2e08cacaf0ac82',1,'last_id_obj():&#160;MediaLib.cc'],['../struttura__dati_8h.html#a43b124c8cd8b452d9b2e08cacaf0ac82',1,'last_id_obj():&#160;MediaLib.cc']]],
  ['last_5fid_5fpeople',['last_id_people',['../MediaLib_8cc.html#a462733b93cf4c091e0ef2fa349c151c8',1,'last_id_people():&#160;MediaLib.cc'],['../struttura__dati_8h.html#a462733b93cf4c091e0ef2fa349c151c8',1,'last_id_people():&#160;MediaLib.cc']]],
  ['leggi_5friga',['leggi_riga',['../inserisci__elimina_8cc.html#a75dc118355081110a2dce486cc459968',1,'leggi_riga(istream &amp;is, char *riga):&#160;inserisci_elimina.cc'],['../inserisci__elimina_8h.html#a75dc118355081110a2dce486cc459968',1,'leggi_riga(istream &amp;is, char *riga):&#160;inserisci_elimina.cc']]],
  ['leggi_5friga_5ff',['leggi_riga_f',['../caricamento__salvataggio_8cc.html#ad6d37e75be8e40bcd7317f2dd94dce32',1,'caricamento_salvataggio.cc']]],
  ['lista_5fobj',['lista_obj',['../struttura__dati_8h.html#a26e581570cb94bf4fb786c54d6c092f6',1,'struttura_dati.h']]],
  ['lista_5fpeople',['lista_people',['../struttura__dati_8h.html#a97698edf5f088d01b28228f8abbca414',1,'struttura_dati.h']]]
];
