var searchData=
[
  ['salva_5fobj',['salva_obj',['../caricamento__salvataggio_8cc.html#a5dbdd3c89bf4af10420615b47ba275da',1,'salva_obj(lista_obj &amp;testa_obj, ostream &amp;os):&#160;caricamento_salvataggio.cc'],['../caricamento__salvataggio_8h.html#a5dbdd3c89bf4af10420615b47ba275da',1,'salva_obj(lista_obj &amp;testa_obj, ostream &amp;os):&#160;caricamento_salvataggio.cc']]],
  ['salva_5fpeople',['salva_people',['../caricamento__salvataggio_8cc.html#a60afd899e32f6c1fd3a72dc2f2af0f61',1,'salva_people(lista_people &amp;testa_people, ostream &amp;os):&#160;caricamento_salvataggio.cc'],['../caricamento__salvataggio_8h.html#a60afd899e32f6c1fd3a72dc2f2af0f61',1,'salva_people(lista_people &amp;testa_people, ostream &amp;os):&#160;caricamento_salvataggio.cc']]],
  ['salva_5ftutto',['salva_tutto',['../MediaLib_8cc.html#a030c65c9e5534383843fb4bfa0e1d1e9',1,'MediaLib.cc']]],
  ['stampa_5fobj_5fper_5ftitolo',['stampa_obj_per_titolo',['../operazioni__ricerca_8cc.html#adc52e9b540ff2833a5920d6ccb7d8683',1,'stampa_obj_per_titolo(lista_obj &amp;testa_obj):&#160;operazioni_ricerca.cc'],['../operazioni__ricerca_8h.html#adc52e9b540ff2833a5920d6ccb7d8683',1,'stampa_obj_per_titolo(lista_obj &amp;testa_obj):&#160;operazioni_ricerca.cc']]],
  ['status',['status',['../structelem__obj.html#ab511805114bf46972e8a95020556f29c',1,'elem_obj']]],
  ['struttura_5fdati_2eh',['struttura_dati.h',['../struttura__dati_8h.html',1,'']]]
];
