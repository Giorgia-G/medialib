var searchData=
[
  ['d1',['D1',['../struttura__dati_8h.html#a330bea9b36f638349fec0d06c8ab4c38',1,'struttura_dati.h']]],
  ['d2',['D2',['../struttura__dati_8h.html#a975397c373ae2a9dc28d0297fa18da56',1,'struttura_dati.h']]],
  ['dbg',['DBG',['../struttura__dati_8h.html#a9fd176efd6d22cb809550f0271c2a93d',1,'struttura_dati.h']]]
];
