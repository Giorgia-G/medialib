var searchData=
[
  ['birth_5fyear',['birth_year',['../structelem__people.html#ad1cbc1268ef5332f5d212d9fb112e0ce',1,'elem_people']]],
  ['builder',['builder',['../caricamento__salvataggio_8cc.html#afa501dbb63ae6077ac8db76b560de42b',1,'builder():&#160;MediaLib.cc'],['../inserisci__elimina_8cc.html#afa501dbb63ae6077ac8db76b560de42b',1,'builder():&#160;MediaLib.cc'],['../MediaLib_8cc.html#afa501dbb63ae6077ac8db76b560de42b',1,'builder():&#160;MediaLib.cc'],['../operazioni__ricerca_8cc.html#afa501dbb63ae6077ac8db76b560de42b',1,'builder():&#160;MediaLib.cc']]]
];
