var searchData=
[
  ['pun',['pun',['../structelem__obj.html#ad1d4d2f683c306e4865deaecff316120',1,'elem_obj']]],
  ['pun_5fp',['pun_p',['../structelem__people.html#a0b60755a6239d425187cfc893729583a',1,'elem_people']]]
];
