var searchData=
[
  ['author_5fname',['author_name',['../structelem__obj.html#a4711f5d03bd2f76015a6aabe04b9858d',1,'elem_obj']]],
  ['author_5fsurname',['author_surname',['../structelem__obj.html#a009f3f42868bdd2a24458b4d8423f007',1,'elem_obj']]]
];
