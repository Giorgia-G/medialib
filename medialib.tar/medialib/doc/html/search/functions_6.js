var searchData=
[
  ['prestito_5frisorsa',['prestito_risorsa',['../MediaLib_8cc.html#a6d52ca03375dce63f1951a21482c2f9e',1,'MediaLib.cc']]],
  ['prestito_5frisorsa_5finsert',['prestito_risorsa_insert',['../MediaLib_8cc.html#ab8604ac17d799fc9411e58b8aa057264',1,'MediaLib.cc']]],
  ['proroga_5fprestito',['proroga_prestito',['../operazioni__ricerca_8cc.html#a3ec9585db7c23bb43d5f70743333b4f6',1,'proroga_prestito(lista_obj &amp;testa_obj):&#160;operazioni_ricerca.cc'],['../operazioni__ricerca_8h.html#a3ec9585db7c23bb43d5f70743333b4f6',1,'proroga_prestito(lista_obj &amp;testa_obj):&#160;operazioni_ricerca.cc']]],
  ['proroga_5fprestito_5fclose',['proroga_prestito_close',['../MediaLib_8cc.html#ab22cd181030a3245c2146d4f447276ae',1,'MediaLib.cc']]],
  ['proroga_5frisorsa',['proroga_risorsa',['../MediaLib_8cc.html#af4dd41ab28c25f8ca69a7ba67f71a4bf',1,'MediaLib.cc']]],
  ['proroga_5frisorsa_5finsert',['proroga_risorsa_insert',['../MediaLib_8cc.html#a24f86cdb83cd24cd9dcc04b914b26334',1,'MediaLib.cc']]]
];
