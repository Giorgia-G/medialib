var searchData=
[
  ['lista_5fobj',['lista_obj',['../struttura__dati_8h.html#a26e581570cb94bf4fb786c54d6c092f6',1,'struttura_dati.h']]],
  ['lista_5fpeople',['lista_people',['../struttura__dati_8h.html#a97698edf5f088d01b28228f8abbca414',1,'struttura_dati.h']]]
];
