var searchData=
[
  ['restituzione_5frisorsa',['restituzione_risorsa',['../MediaLib_8cc.html#a880542f9a57524e51fcd2fb1957c4856',1,'MediaLib.cc']]],
  ['restituzione_5frisorsa_5finsert',['restituzione_risorsa_insert',['../MediaLib_8cc.html#a7e464bba24991bed4c483da69c6aaa8c',1,'MediaLib.cc']]],
  ['ritorna_5fprestito',['ritorna_prestito',['../operazioni__ricerca_8cc.html#a04537eeb013972bbf0f59135e31b1cae',1,'ritorna_prestito(lista_obj &amp;testa_obj):&#160;operazioni_ricerca.cc'],['../operazioni__ricerca_8h.html#a04537eeb013972bbf0f59135e31b1cae',1,'ritorna_prestito(lista_obj &amp;testa_obj):&#160;operazioni_ricerca.cc']]]
];
