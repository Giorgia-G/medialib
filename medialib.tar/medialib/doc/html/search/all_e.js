var searchData=
[
  ['testa_5fobj',['testa_obj',['../MediaLib_8cc.html#aecb1465bdbee134cee9ea4264d539af9',1,'testa_obj():&#160;MediaLib.cc'],['../struttura__dati_8h.html#aecb1465bdbee134cee9ea4264d539af9',1,'testa_obj():&#160;MediaLib.cc']]],
  ['testa_5fpeople',['testa_people',['../MediaLib_8cc.html#a23d0c1434db8bad581b48535ceed70b5',1,'testa_people():&#160;MediaLib.cc'],['../struttura__dati_8h.html#a23d0c1434db8bad581b48535ceed70b5',1,'testa_people():&#160;MediaLib.cc']]],
  ['title',['title',['../structelem__obj.html#ab421a589541926e37697fe64b48c4803',1,'elem_obj']]],
  ['type',['type',['../structelem__obj.html#a04c2167357acead0672d08231d7abe00',1,'elem_obj']]]
];
