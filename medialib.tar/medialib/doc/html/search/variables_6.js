var searchData=
[
  ['n_5ftelefono',['n_telefono',['../structelem__people.html#add99b5efd9cb952cdf68e34ff56f4335',1,'elem_people']]],
  ['nome_5ffile_5fobj',['NOME_FILE_OBJ',['../MediaLib_8cc.html#a5128b7b03e9e9e13941bbd802956e15b',1,'NOME_FILE_OBJ():&#160;MediaLib.cc'],['../struttura__dati_8h.html#a5128b7b03e9e9e13941bbd802956e15b',1,'NOME_FILE_OBJ():&#160;MediaLib.cc']]],
  ['nome_5ffile_5fpeo',['NOME_FILE_PEO',['../MediaLib_8cc.html#a17480d5ea97cd6c92c5cf724aa5b4da1',1,'NOME_FILE_PEO():&#160;MediaLib.cc'],['../struttura__dati_8h.html#a17480d5ea97cd6c92c5cf724aa5b4da1',1,'NOME_FILE_PEO():&#160;MediaLib.cc']]]
];
