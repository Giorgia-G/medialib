var searchData=
[
  ['operazioni_5fricerca_2ecc',['operazioni_ricerca.cc',['../operazioni__ricerca_8cc.html',1,'']]],
  ['operazioni_5fricerca_2eh',['operazioni_ricerca.h',['../operazioni__ricerca_8h.html',1,'']]]
];
