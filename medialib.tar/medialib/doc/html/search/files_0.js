var searchData=
[
  ['caricamento_5fsalvataggio_2ecc',['caricamento_salvataggio.cc',['../caricamento__salvataggio_8cc.html',1,'']]],
  ['caricamento_5fsalvataggio_2eh',['caricamento_salvataggio.h',['../caricamento__salvataggio_8h.html',1,'']]]
];
