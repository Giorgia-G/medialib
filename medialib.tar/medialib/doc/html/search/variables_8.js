var searchData=
[
  ['rel_5fdate',['rel_date',['../structelem__obj.html#acec770d9b422bbf166777c78c51f49f4',1,'elem_obj']]],
  ['return_5fdate',['return_date',['../structelem__obj.html#ababe85ca8aec60e6236131bf4ad59c1f',1,'elem_obj']]]
];
